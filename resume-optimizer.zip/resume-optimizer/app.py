#!/usr/bin/env python3
"""AI 简历优化器 — Flask Backend"""

import os, re, json, base64, uuid, tempfile, time
from flask import Flask, render_template, request, jsonify, send_file

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# ──────────────────────────────────────────────────────────────
# AI 服务商预设
# ──────────────────────────────────────────────────────────────
PROVIDERS = {
    "deepseek": {
        "name": "DeepSeek",
        "apiUrl": "https://api.deepseek.com/v1/chat/completions",
        "model": "deepseek-chat",
        "description": "性价比高，中文能力强",
    },
    "qwen": {
        "name": "通义千问 (Qwen)",
        "apiUrl": "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
        "model": "qwen-plus",
        "description": "阿里大模型，擅长中文",
    },
    "moonshot": {
        "name": "Moonshot (Kimi)",
        "apiUrl": "https://api.moonshot.cn/v1/chat/completions",
        "model": "moonshot-v1-8k",
        "description": "长文本处理能力强",
    },
    "zhipu": {
        "name": "智谱 AI (GLM)",
        "apiUrl": "https://open.bigmodel.cn/api/paas/v4/chat/completions",
        "model": "glm-4-flash",
        "description": "清华系大模型",
    },
}

# ──────────────────────────────────────────────────────────────
# 路由
# ──────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────
# 工具函数
# ──────────────────────────────────────────────────────────────
CHAT_PATH = "/v1/chat/completions"


def _normalize_api_url(url):
    """智能补全 API 地址"""
    url = url.rstrip("/")
    if CHAT_PATH in url:
        return url
    # 用户只填了基础域名，自动追加路径
    return url + CHAT_PATH


# ──────────────────────────────────────────────────────────────
# 路由
# ──────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/providers")
def get_providers():
    return jsonify(PROVIDERS)


@app.route("/api/upload-photo", methods=["POST"])
def upload_photo():
    """上传头像，返回 base64"""
    f = request.files.get("photo")
    if not f:
        return jsonify({"error": "未收到文件"}), 400
    data = f.read()
    if len(data) > 5 * 1024 * 1024:
        return jsonify({"error": "图片不能超过 5MB"}), 400
    b64 = base64.b64encode(data).decode("utf-8")
    mime = f.content_type or "image/jpeg"
    return jsonify({"base64": b64, "mimeType": mime})


@app.route("/api/optimize", methods=["POST"])
def optimize():
    """调用 LLM 优化简历"""
    data = request.json
    jd = data.get("jd", "")
    resume = data.get("resume", "")
    provider = data.get("provider", "deepseek")
    api_key = data.get("apiKey", "")
    api_url = data.get("apiUrl", "")
    model = data.get("model", "")

    if not api_key:
        return jsonify({"error": "请填写 API Key"}), 400
    if not jd.strip():
        return jsonify({"error": "请填写目标岗位的 JD"}), 400
    if not resume.strip():
        return jsonify({"error": "请填写简历内容"}), 400

    # 如果没有自定义 URL，使用预设
    p = PROVIDERS.get(provider, PROVIDERS["deepseek"])
    if not api_url:
        api_url = p["apiUrl"]
    if not model:
        model = p["model"]

    # 智能补全 API 地址：如果用户只填了基础域名，自动追加 /v1/chat/completions
    api_url = _normalize_api_url(api_url)

    system_prompt = (
        "你是一位资深的简历优化专家。你的任务是在**完整保留原始简历所有内容**的前提下，"
        "对措辞进行润色，使其更好地匹配目标岗位。\n\n"
        "【最高优先级规则 —— 违反即失败】\n"
        "1. 必须保留原始简历中的**每一个章节、每一条经历、每一个要点、每一行文字**，"
        "禁止删除、省略、合并、缩减任何内容\n"
        "2. 必须保持原始简历的**章节顺序和条目顺序**，禁止重新排列\n"
        "3. 工作经历：原始简历中有几段工作经历，输出就必须有几段工作经历，每段的所有描述项全部保留\n"
        "4. 项目经历：原始简历中有几个项目，输出就必须有几个项目，每个项目的全部描述项全部保留\n"
        "5. 教育经历：完整保留，不得省略\n"
        "6. 个人优势 / 个人介绍 / 自我评价：这是唯一需要**根据 JD 重新撰写**的章节。"
        "请按以下结构撰写：\n"
        "  a) 先用一句话概括候选人的核心竞争力（总括句）\n"
        "  b) 然后贴合 JD 分点陈述优势，每个分点格式为：- **小标题：** 详细描述\n"
        "     小标题需精炼（3-5字），概括该点优势方向；详细描述需结合候选人真实经历\n"
        "  c) 分点数量 3-5 个，紧密围绕 JD 核心要求\n"
        "7. 基本信息（姓名、联系方式、工作年限等）：完整保留\n\n"
        "【允许的操作】\n"
        "- 对现有描述的措辞进行润色，使其更专业、更匹配 JD\n"
        "- 适当补充量化数据（仅限可从原文合理推断的数据）\n"
        "- 优化排版格式使其更整齐\n"
        "- 在不改变原意的前提下调整用词\n\n"
        "【红色高亮关键数据】\n"
        "对于正文中出现的关键结果数据和里程碑数字（如金额、增长率、用户量、准确率、排名等），"
        "请用 ==数字== 语法包裹，使其在 PDF 中显示为红色。例如：\n"
        "- 原文：「连续 4 个月破千万」→ 输出：「连续 ==4 个月== 破千万」\n"
        "- 原文：「准确率 99.38%」→ 输出：「准确率 ==99.38%==」\n"
        "- 原文：「服务 200 万+ 用户」→ 输出：「服务 ==200 万+== 用户」\n"
        "注意：仅高亮具体的数字和数据，不要高亮普通文字；克制使用，每段经历高亮 1-3 处即可\n\n"
        "【禁止的操作】\n"
        "- 删除任何章节或条目\n"
        "- 合并多条为一条\n"
        "- 改变章节顺序\n"
        "- 编造全新的经历或项目\n"
        "- 将详细描述缩减为一句话概述\n\n"
        "【输出格式】\n"
        "保持与原始简历相同的 Markdown 结构。具体来说：\n"
        "- # 姓名\n"
        "- 基本信息行（性别、年龄、联系方式等）\n"
        "- --- 分隔线\n"
        "- ## 各大章节标题（与原文一致）\n"
        "- ### 子标题（公司名、项目名等，与原文一致）\n"
        "- 列表项、段落等（与原文条目数量一致）\n"
        "- --- 分隔线（章节之间）"
    )

    try:
        import requests as req_lib
        resp = req_lib.post(
            api_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": (
                            f"## 目标岗位 JD\n\n{jd}\n\n"
                            f"## 原始简历\n\n{resume}\n\n"
                            "请根据 JD 对这份简历进行优化：\n"
                            "1. 【个人优势/个人介绍】部分请根据 JD 核心要求重新撰写，高度贴合岗位需求\n"
                            "2. 【其他所有章节】必须完整保留原始简历中的每一条内容，不得删除、合并或重排，仅润色措辞"
                        ),
                    },
                ],
                "temperature": 0.4,
                "max_tokens": 16000,
            },
            timeout=180,
        )
        resp.raise_for_status()
        result = resp.json()
        content = result["choices"][0]["message"]["content"]
        return jsonify({"optimized": content, "model_used": model})
    except Exception as e:
        return jsonify({"error": f"AI 调用失败：{str(e)}"}), 500


@app.route("/api/generate-pdf", methods=["POST"])
def generate_pdf():
    """将优化后的简历渲染为东方水墨风格 PDF"""
    data = request.json
    markdown_text = data.get("markdown", "")
    photo_b64 = data.get("photo", "")
    photo_mime = data.get("photoMime", "image/jpeg")

    if not markdown_text.strip():
        return jsonify({"error": "没有可生成的内容"}), 400

    # 构建完整 HTML
    html_content = build_resume_html(markdown_text, photo_b64, photo_mime)

    # Playwright 生成 PDF
    from playwright.sync_api import sync_playwright

    tmp_path = os.path.join(tempfile.gettempdir(), f"resume_{uuid.uuid4().hex[:8]}.pdf")

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.set_content(html_content, wait_until="networkidle")
            page.wait_for_timeout(2000)
            page.pdf(
                path=tmp_path,
                format="A4",
                print_background=True,
                margin={"top": "8mm", "bottom": "8mm", "left": "10mm", "right": "10mm"},
            )
            browser.close()
    except Exception as e:
        return jsonify({"error": f"PDF 生成失败：{str(e)}"}), 500

    filename = f"优化简历-{time.strftime('%Y%m%d')}.pdf"
    return send_file(
        tmp_path,
        mimetype="application/pdf",
        as_attachment=True,
        download_name=filename,
    )


# ──────────────────────────────────────────────────────────────
# 工具函数
# ──────────────────────────────────────────────────────────────
def markdown_to_html(md_text):
    """简易 Markdown → HTML 转换（针对简历场景优化）

    支持的语法：
      # h1        → <h1 class="name">
      ## h2       → <h2 class="section-title">
      ### h3      → <h3 class="sub-title">
      ---         → <div class="divider">
      - / *       → <ul><li>（连续项合并到同一个 <ul>）
      **bold**    → <strong>
      *italic*    → <em>
      [txt](url)  → <a>
      普通段落     → <p>
    """
    lines = md_text.strip().split("\n")
    html_parts = []
    in_list = False

    for line in lines:
        stripped = line.strip()

        # ── 空行：关闭当前列表 ──
        if not stripped:
            if in_list:
                html_parts.append("</ul>")
                in_list = False
            continue

        # ── 水平分割线 ──
        if stripped in ("---", "***", "___"):
            if in_list:
                html_parts.append("</ul>")
                in_list = False
            html_parts.append('<div class="divider"></div>')
            continue

        # ── h1（姓名） ──
        if stripped.startswith("# ") and not stripped.startswith("## "):
            if in_list:
                html_parts.append("</ul>")
                in_list = False
            text = _inline(stripped[2:])
            html_parts.append(f'<h1 class="name">{text}</h1>')
            continue

        # ── h2（章节标题） ──
        if stripped.startswith("## "):
            if in_list:
                html_parts.append("</ul>")
                in_list = False
            text = _inline(stripped[3:])
            html_parts.append(f'<h2 class="section-title">{text}</h2>')
            continue

        # ── h3（子标题：公司/项目） ──
        if stripped.startswith("### "):
            if in_list:
                html_parts.append("</ul>")
                in_list = False
            text = _inline(stripped[4:])
            html_parts.append(f'<h3 class="sub-title">{text}</h3>')
            continue

        # ── 无序列表项（- 或 *） ──
        if stripped.startswith("- ") or stripped.startswith("* "):
            if not in_list:
                html_parts.append("<ul>")
                in_list = True
            text = _inline(stripped[2:])
            html_parts.append(f"<li>{text}</li>")
            continue

        # ── 普通段落 ──
        if in_list:
            html_parts.append("</ul>")
            in_list = False
        html_parts.append(f"<p>{_inline(stripped)}</p>")

    # 关闭末尾未闭合的列表
    if in_list:
        html_parts.append("</ul>")

    return "\n".join(html_parts)


def _inline(text):
    """处理行内 Markdown 语法：bold、italic、link、==红色高亮=="""
    # Red highlight: ==text==  (must come before bold to avoid conflict)
    text = re.sub(r"==(.+?)==", r'<span class="metric">\1</span>', text)
    # Bold: **text**
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    # Italic: *text*
    text = re.sub(r"\*(.+?)\*", r"<em>\1</em>", text)
    # Links: [text](url)
    text = re.sub(r"\[(.+?)\]\((.+?)\)", r'<a href="\2" target="_blank">\1</a>', text)
    return text


def build_resume_html(markdown_text, photo_b64, photo_mime):
    """构建东方水墨风格的完整简历 HTML（供 Playwright 渲染 PDF）"""
    body_html = markdown_to_html(markdown_text)

    # ── 头像标签 ──
    photo_tag = ""
    if photo_b64:
        mime = photo_mime or "image/jpeg"
        src = f"data:{mime};base64,{photo_b64}"
        photo_tag = (
            f'<div class="photo-wrap">'
            f'<img class="photo-img" src="{src}" alt="头像">'
            f'</div>'
        )

    # ── 页眉提示（固定右上角） ──
    header_notice = (
        '<div class="pdf-header-notice">'
        '所有文字均为人工手打，仅样式设计使用AI，请放心使用'
        '</div>'
    )

    # ── 读取模板并替换占位符 ──
    template_path = os.path.join(
        os.path.dirname(__file__), "templates", "resume_template.html"
    )
    with open(template_path, "r", encoding="utf-8") as f:
        template = f.read()

    html = template.replace("{{PHOTO}}", photo_tag)
    html = html.replace("{{HEADER_NOTICE}}", header_notice)
    html = html.replace("{{RESUME_CONTENT}}", body_html)

    return html


# ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 50)
    print("  AI 简历优化器")
    print("  打开浏览器访问: http://localhost:5001")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5001, debug=True)
